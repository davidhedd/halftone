package com.halftone.halftone.layout;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.halftone.halftone.R;

public class UploadFragment extends Fragment {
    ImageView addTagsView;
    public static UploadFragment newInstance() {
        return new UploadFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View myView = inflater.inflate(R.layout.fragment_upload, container, false);
        addTagsView = (ImageView) myView.findViewById(R.id.addTagsIcon);
        addTagsView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
                String[] colors = {"red", "yellow", "green"};
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("hello")
                        .setItems(colors, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // The 'which' argument contains the index position
                                // of the selected item
                            }
                        });
                builder.create();
            }
        });
        return myView;
    }
}