package com.halftone.halftone.layout;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.halftone.halftone.R;

import java.io.ByteArrayOutputStream;

public class UploadActivity extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;

    // Layout for Upload
    //public Bitmap takePhotoLabel = Bitmap.createBitmap(Bitmap.DENSITY_NONE, 100, Bitmap.Config.RGB_565);
    private TextView addPhotoLabel, addTagLabel, addLocationLabel;
    private ImageView takePhotoIcon, addTagIcon, addLocationIcon;
    private Button uploadButton;

    // Firebase Database instance
    // Write a message to the database
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_upload:
                    return true;
                case R.id.navigation_explore:
                    startActivity(new Intent(UploadActivity.this, ExploreActivity.class));
                    return true;
                case R.id.navigation_profile:
                    startActivity(new Intent(UploadActivity.this, ProfileActivity.class));
                    return true;
            }
            return false;
        }

    };

    String mCurrentPhotoPath;

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            //takePhotoIcon.setImageBitmap(imageBitmap);
            encodeBitmapAndSaveToFirebase(imageBitmap);
        }
    }

    public void encodeBitmapAndSaveToFirebase(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        String imageEncoded = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
        /*
            Fix connection to database
         */
        DatabaseReference m = databaseReference.child("BucketList");
        DatabaseReference m1 = m.push();
        m1.setValue(imageEncoded);
    }

    public void onLaunchCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);

        firebaseDatabase = FirebaseDatabase.getInstance();

        // Make camera upload intent and other fields to upload post
        addPhotoLabel = new TextView(getApplicationContext());
        addPhotoLabel.setText(R.string.add_photo_label);
        addTagLabel = new TextView(getApplicationContext());
        addTagLabel.setText(R.string.add_tags_label);
        addLocationLabel = new TextView(getApplicationContext());
        addLocationLabel.setText(R.string.add_location_label);
        uploadButton = new Button(getApplicationContext());
        uploadButton.setText(R.string.upload_button);
        // onLaunchCamera();

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

}
