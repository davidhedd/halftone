package com.halftone.halftone.layout;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.halftone.halftone.R;

public class ExploreActivity extends AppCompatActivity {

    // Layout for Explore
    private TextView usernameLabel, locationLabel;
    private ImageView postImage;
    private Button shareButton, filterButton;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_upload:
                    startActivity(new Intent(ExploreActivity.this, UploadActivity.class));
                    return true;
                case R.id.navigation_explore:
                    return true;
                case R.id.navigation_profile:
                    startActivity(new Intent(ExploreActivity.this, ProfileActivity.class));
                    return true;
            }
            return false;
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explore);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

}
